EECS 391 Programming Assignment 2
March 3 2016
Sarah Whelan (slw96)

One of my personal goals for this project was to make it extensible past two archers/two footmen
so there are only a few places in the code that make use of the known number of archers/footmen.

I was told that there would be at most 2 of each type so I hope this is okay. It has introduced some
complexity that would be unecessary if there were only two but I appreciate that it is relatively close
to being general.