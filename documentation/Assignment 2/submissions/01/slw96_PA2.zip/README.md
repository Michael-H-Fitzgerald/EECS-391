EECS 391 Programming Assignment 2
March 3 2016
Sarah Whelan (slw96)