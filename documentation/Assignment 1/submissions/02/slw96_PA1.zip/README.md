# Programming Assignment 1

## Sarah Whelan (slw96)

In addition to AstarSearch and shouldReplanPath the methods I added were:
 - hasEnemyMovementMattered
 - isEnemyInNextFewSteps
 - exploreNode
 - generatePathFromEndNode
 - getLocationForDirection
 
I ended up only adding one line of code to the original provided code and that is I added a System.exit(0) call as the last line of terminal step. This is just to prevent the looping after the townhall has been destroyed on the dynamic map. If this is causing problems for testing removing it is totally fine.